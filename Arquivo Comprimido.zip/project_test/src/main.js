import bodyParser from 'body-parser';
import express from 'express';
import router from './services/controller';

var app = express();
app.use(bodyParser.json({ type: 'application/json' }));
app.use(bodyParser.raw({ type: 'application/bin', limit : '10mb' }));

app.use('/controller', router);

app.listen(8080, function () {
  console.log('Project test app listening on port 8080!');
});
