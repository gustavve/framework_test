class Helper {

  async getNumberDivisors(num){
    let numbers = [];
    for(let i = 0; i <= num; i++){
        if(num % i == 0){
          numbers.push(i);
        }
    }
    return numbers;
  }

  async primeNumbersDivisores (num) {
    let numbers = [];
    for (var i = 0; i <= num; i++) {
      if (this.isPrimeNumber(i)){
        if(num % i === 0) {
          numbers.push(i);
        }
      }
    }
    return numbers;
  }

  isPrimeNumber (num) {
    for(let i = 2; i < num; i++)
      if(num % i === 0) {
          return false
      };
    return num > 0;
  }
}

module.exports = Helper;
