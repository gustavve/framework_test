npm install

npm start
