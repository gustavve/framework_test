var assert = require('assert');
var Services = require('../services/services')

let test_45 = {
  divisors: [1,3,5, 9, 15, 45],
  prime_numbers: [1, 3, 5]
}

let test_723 = {
  divisors: [1, 3, 241, 723],
  prime_numbers: [1, 3, 241]
}

let test_1245 = {
  divisors: [1, 3, 5, 15, 83, 249, 415, 1245],
  prime_numbers: [1, 3, 5, 83]
}

describe('Unit tests divisors numbers [45, 723, 1245]', function () {
  it('Unit test divisors number 45', async () => {
    let service = new Services()
    assert.equal(JSON.stringify(test_45), JSON.stringify(await service.getNumberDivisors({number: 45})));
  });

  it('Unit test divisors number 723', async () => {
    let service = new Services()
    assert.equal(JSON.stringify(test_723), JSON.stringify(await service.getNumberDivisors({number: 723})));
  });

  it('Unit test divisors number 1245', async () => {
    let service = new Services()
    assert.equal(JSON.stringify(test_1245), JSON.stringify(await service.getNumberDivisors({number: 1245})));
  });
});