import express from 'express'
import Services from './services'
import asyncMiddleware from '../utils/AsyncMiddleware'

let router = express.Router();

router.get('/divisors_numbers', asyncMiddleware( async (req, res, next) => {
  console.log("Dados da Requisicao", req.query);

  try {
    let service = new Services();
    let result = await service.getNumberDivisors(req.query);
    if (!result) {
      res.status(500).end();
    } else {
      console.log("Retornando pend", result);
      res.json(result);
    }
  } catch (e) {
    res.status(400).send(e);
  }
}));

module.exports = router;