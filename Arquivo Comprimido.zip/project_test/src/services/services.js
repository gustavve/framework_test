import Helper from '../helpers/helper'

class Services{
  async getNumberDivisors(query){

    let helper = new Helper();

    let divisors = await helper.getNumberDivisors(query.number);
    let primeNumbers = await helper.primeNumbersDivisores(query.number);

    return { divisors: divisors, prime_numbers: primeNumbers};
  }
}

module.exports = Services;
